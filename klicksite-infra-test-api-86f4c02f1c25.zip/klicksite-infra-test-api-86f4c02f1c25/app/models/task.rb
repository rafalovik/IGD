class Task < ApplicationRecord
  belongs_to :stage
end
