FactoryGirl.define do
  factory :stage do
    name "MyString"
  end
end
