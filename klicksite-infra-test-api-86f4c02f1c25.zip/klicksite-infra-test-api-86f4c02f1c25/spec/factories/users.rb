FactoryGirl.define do
  factory :user do
    name "MyString"
    email "MyString"
  end
end
