FactoryGirl.define do
  factory :task do
    title "MyString"
    description "MyString"
    stage nil
  end
end
